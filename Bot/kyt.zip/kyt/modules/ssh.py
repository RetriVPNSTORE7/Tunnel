from kyt import *

#DELETESSH
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Username To Be Deleted:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | del-ssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Successfully Deleted**")
		else:
			await event.respond(f"**Successfully Deleted** `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as pw1:
			await event.respond("**Limit-ip:**")
			pw1 = pw1.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw1 = (await pw1).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Expaired:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(0)
		await event.edit("`Processing... 84%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(1)
		await event.edit("`Tunggu... Sebentar`")
		cmd = f'printf "%s\n" "{user}" "{pw}" "{pw1}" "{exp}" | add-ssh'
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
TERIMA KASIH TELAH MENGGUNAKAN
SCRIPT PREMIUM BY @RetriVpn
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'bot-member-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
**Show All SSH User**
**» 🤖@RetriVpn**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)



@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Minutes:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(0)
		await event.edit("`Processing... 84%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n▰▱▰▱▰▱▰▱ `")
		time.sleep(1)
		await event.edit("`Tunggu... Sebentar`")
		cmd = f'printf "%s\n" "{exp}" | trial-ssh'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
TERIMA KASIH TELAH MENGGUNAKAN SCRIPT
PREMIUM BY @RetriVpn
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'bot-cek-login-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**shows logged in users SSH Ovpn**
**» 🤖@RetriVpn**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" TRIAL SSH ","trial-ssh"),
Button.inline(" CREATE SSH ","create-ssh")],
[Button.inline(" DELETE SSH ","delete-ssh"),
Button.inline(" CHECK Login SSH ","login-ssh")],
[Button.inline(" SHOW All USER SSH ","show-ssh"),
Button.inline(" REGIS IP ","regis")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
◆━━━━━━━━━━━━━━━◆
**⚡ SSH OVPN MANAGER ⚡**
◆━━━━━━━━━━━━━━━◆
 **» 🔰Service:** `SSH OVPN`
 **» 🔰Hostname/IP:** `{DOMAIN}`
 **» 🔰ISP:** `{z["isp"]}`
 **» 🔰Country:** `{z["country"]}`
 **» 🔰@RetriVpn**
◆━━━━━━━━━━━━━━━◆ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
